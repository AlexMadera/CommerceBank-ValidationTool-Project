Demo of the application working: https://youtu.be/-SuwNYEHoJQ

I hope you enjoy =)